import axios from "axios";
import React, { useState } from "react";


const App = () => {
  const [user, setUser] = useState({
    username: "",
  });


  const [data, setData] = useState();
  const [editUser, setEditUser] = useState();
  const [handleShow, setHandleShow] = useState(false);

  const handleChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!user?.username) {
      console.error("Please enter valid details");
    } else {
      await axios.post(
        "https://crude-3dcf5-default-rtdb.firebaseio.com/crude.json",
        user
      );
      const response = await axios.get(
        "https://crude-3dcf5-default-rtdb.firebaseio.com/crude.json"
      );
      
      if (response?.status === 200) {
        const dataUser = Object.values(response?.data);
        const dataKey = Object.keys(response?.data);

        dataKey?.map((element, index) => (dataUser[index].id = element));
        setData(dataUser);
      } else {
        console.error("Error FOund");
      }
    }
  };

  const handleEdit = (id) => {
    const response = data?.find((element) => element?.id === id);
    setEditUser(response);
    setHandleShow(true);
  };
// Edit Input
  const handleEditChange = (e) => {
    setEditUser({ ...editUser, [e.target.name]: e.target.value })
  }


  const handleUpdate = async (e) => {
    e.preventDefault();
    await axios.put(`https://crude-3dcf5-default-rtdb.firebaseio.com/crude/${editUser?.id}.json`, editUser);
    const response = await axios.get(
      "https://crude-3dcf5-default-rtdb.firebaseio.com/crude.json"
    );
    if (response?.status === 200) {
      const dataUser = Object.values(response?.data);
      const dataKey = Object.keys(response?.data);
      dataKey?.map((element, index) => (dataUser[index].id = element));
      setData(dataUser);
    } else {
      console.error("Error FOund");
    }
  };
  



  const handleDelete =  async(id) => {
    await axios.delete(`https://crude-3dcf5-default-rtdb.firebaseio.com/${id}.json`)
        const updatedData =  data.filter((element) => element.id !== id);
 setData(updatedData);
  };

  return (
    <div>
      <form action="#" onSubmit={handleSubmit}>
        <input
          type="text"
          value={user?.username}
          name="username"
          placeholder="Enter username"
          onChange={handleChange}
          style={{ padding: "10px", margin: "100px" }}
        />
        <input type="submit" value="Submit" />
      </form>

      <div>
        {data?.map((element, index) => {
          return (
            <div key={index}>
              <h3>{element?.username}</h3>
              <button onClick={() => handleEdit(element?.id)}>Edit</button>
              <button onClick={() => handleDelete(element?.id)}>Delete</button>
            </div>
          );
        })}
      </div>

      <div>
        {handleShow ? (
          <>
            <form action="#" onSubmit={handleUpdate}>
              <input
                type="text"
                value={editUser?.username}
                name="username"
                placeholder="Enter username"
                onChange={handleEditChange}
                style={{ padding: "10px" }}
              />
              <input type="submit" value="Submit" />
            </form>
          </>
        ) : (
          ""
        )}
      </div>
    </div>
  );
};

export default App;
