import * as React from 'react';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { blogDatabase, fetchData } from '../../../config';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { useEffect } from 'react';
import axios from 'axios';


export default function Blog() {

  // const [blogs, setBlogs] = useState(blogDatabase)
  const [blogs, setBlogs] = useState()
  const [editBlog, setEditBlog] = useState()
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);

  const handleShow = (id) => {
    setShow(true);
    const response = blogs?.find((blog) => blog.blogId === id)
    setEditBlog(response)
  };

  const editHandle = async (id) => {
    handleClose()
    await axios.put(`https://blogginh-web-default-rtdb.asia-southeast1.firebasedatabase.app/blogs/${id}.json`, editBlog)
    responseData()
  }

  const handleChange = (e) => {
    setEditBlog({...editBlog, [e.target.name] : e.target.value})
  }

  const deleteHandle = async (id) => {
      await axios.delete(`https://blogginh-web-default-rtdb.asia-southeast1.firebasedatabase.app/blogs/${id}.json`)
      responseData()
  }

  const responseData = async () => {
    const response = await fetchData("blogs")
    setBlogs(response)
  }


  useEffect(() => {
    responseData()
  },[])

  return (

    <div className="container">
      <div className="row mt-5">
        {
          blogs?.map((blog, index) => <div className="col-3" key={index}>
            <Box sx={{ minWidth: 275 }}>
              <Card variant="outlined"><React.Fragment>
                <CardContent>
                  <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
                    {blog.category}
                  </Typography>
                  <Typography variant="h5" component="div">
                    {blog.title}
                  </Typography>
                  <Typography sx={{ mb: 1.5 }} color="text.secondary">
                    {blog.desription}
                  </Typography>
                </CardContent>
                <CardActions>
                  <button onClick={() => handleShow(blog?.blogId)} class="btn btn-primary">Edit </button>
                  <button className='btn btn-danger' onClick={() => deleteHandle(blog?.blogId)}>Delete </button>
                </CardActions>
              </React.Fragment></Card>
            </Box>
          </div>)
        }

        <Modal show={show} onHide={handleClose}>
          <Modal.Header closeButton>
            <Modal.Title>Modal heading</Modal.Title>
          </Modal.Header>
          <Modal.Body>
          <form action="">
            <div className="form-floating mb-3">
              <input type="text" className="form-control"  placeholder='Blog Title'onChange={handleChange} name="title" value={editBlog?.title}/>
                <label htmlFor="floatingInput">Title</label>
            </div>
            <div className="form-floating mb-3">
              <input type="text" className="form-control"  placeholder='Blog Description' onChange={handleChange} name="desription" value={editBlog?.desription}/>
                <label htmlFor="floatingPassword">Description</label>
            </div>
            <div className="form-floating mb-3">
              <input type="text" className="form-control"  placeholder='Blog Category' onChange={handleChange} name="category" value={editBlog?.category}/>
                <label htmlFor="floatingPassword">Category</label>
            </div>
          </form>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button variant="primary" onClick={() => editHandle(editBlog?.blogId)}>
              Save Changes
            </Button>
          </Modal.Footer>
        </Modal>
      </div>
    </div>
  );
}
