import axios from "axios";

export const blogData = {
    title: "",
    desription: "",
    category: "",
    date: new Date()
}

export const blogDatabase = []

export const validateBlog = (blog) => {
    try {
        const response = blogDatabase.filter((vlog) => vlog.title === blog.title);
        if (response.length > 0) {
            return {
                validation: "error",
                isExit: true
            }
        } else {
            return {
                validation: "success",
                isExit: false
            }
        }
    } catch (error) {
        return {
            error: "Found",
            errorCode: "1004"
        }
    }
}
// const response = await axios.post(`process.ENV.${DATA_BASE}${route}.json`, item)
export const sendDataToDB = async (item, route) => {
    const response = await axios.post(`https://api-f08e7-default-rtdb.firebaseio.com/${route}.json`, item)
    console.log(response);
    if (response?.status) {
        return {
            isSend: true,
            data: response
        }
    }
}

export const fetchData = async (route) => {
    const response = await axios.get(`https://api-f08e7-default-rtdb.firebaseio.com/${route}.json`)

    const data = Object?.values(response?.data)
    const keys = Object?.keys(response?.data)

    keys?.map((element, index) => data[index].blogId = element)
    return data

}